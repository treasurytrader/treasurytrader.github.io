﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace NTDirect
{
	public partial class MainWindow : Window
	{
		//  set Build -> Configuration Manager -> Active solution platform -> x86

		[System.Runtime.InteropServices.DllImport("C:\\Windows\\SysWOW64\\NtDirect.dll")]
		public static extern int Connected(int showMessage);

		[System.Runtime.InteropServices.DllImport("C:\\Windows\\SysWOW64\\NtDirect.dll")]
		public static extern int Last(string instrument, double price, int size);

		[System.Runtime.InteropServices.DllImport("C:\\Windows\\SysWOW64\\NtDirect.dll")]
		public static extern int LastPlayback(string instrument, double price, int size, string timestamp);

		[System.Runtime.InteropServices.DllImport("C:\\Windows\\SysWOW64\\NtDirect.dll")]
		public static extern double MarketData(string instrument, int type);

		[System.Runtime.InteropServices.DllImport("C:\\Windows\\SysWOW64\\NtDirect.dll")]
		public static extern int SubscribeMarketData(string instrument);

		[System.Runtime.InteropServices.DllImport("C:\\Windows\\SysWOW64\\NtDirect.dll")]
		public static extern int TearDown();

		[System.Runtime.InteropServices.DllImport("C:\\Windows\\SysWOW64\\NtDirect.dll")]
		public static extern int UnsubscribeMarketData(string instrument);
		
		private int						connected;
		private string					instrumentReceive, instrumentSend;
		private bool					sendLive, sendingData, receivingData;
		private int						mdSubscribed;
		private double					askPriceReceive, bidPriceReceive, lastPriceReceive, priceSend;
		private bool					shuttingDown;
		private int						size;
		private System.Timers.Timer		timerReceive, timerSend;

		public MainWindow()
		{
			InitializeComponent();
			Closed	+= MainWindow_Closed;
			Loaded	+= MainWindow_Loaded;
		}
		
		private void MainWindow_Closed(object sender, EventArgs e)
		{
			if (shuttingDown)
				return;

			if (receivingData)
				UnsubscribeMarketData(instrumentReceive);

			TearDown();

			shuttingDown	= true;
			Application.Current.Shutdown();
		}

		private void MainWindow_Loaded(object sender, RoutedEventArgs e)
		{
			shuttingDown			= false;
			instrumentReceive		= "AAPL";
			instrumentSend			= "MSFT";
			sendLive				= true;
			sendingData				= false;
			receivingData			= false;
			mdSubscribed			= 0;
			timerReceive			= new System.Timers.Timer() { Interval = 1000 };
			timerReceive.Elapsed	+= MarketDataTimerElapsed;
			timerSend				= new System.Timers.Timer() { Interval = 1000 };
			timerSend.Elapsed		+= LastTimerElapsed;

			connected = Connected(1);
			Console.WriteLine(string.Format("{0} | connected: {1}", DateTime.Now, (connected > -1 ? "true" : "false")));
		}

		private void ToggleReceive(object sender, RoutedEventArgs e)
		{
			Button button = sender as Button;

			switch(receivingData)
			{
				case false:
					mdSubscribed			= SubscribeMarketData(instrumentReceive);
					if (mdSubscribed != 0)
						break;

					receivingData			= true;
					timerReceive.Enabled	= true;
					button.Content			= string.Format("Stop Receiving {0}", instrumentReceive);
					break;

				case true:
					mdSubscribed			= UnsubscribeMarketData(instrumentReceive);
					receivingData			= false;
					timerReceive.Enabled	= false;
					button.Content			= string.Format("Receive {0}", instrumentReceive);
					break;
			}
		}

		private void ToggleSend(object sender, RoutedEventArgs e)
		{
			if (!sendLive)
			{
				priceSend = 1.00;

				DateTime dt = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 13, 30, 0);

				for (int i = 0; i < 300; i++)
				{
					Console.WriteLine(string.Format("{0}, {1}, {2}, {3}, {4}", instrumentSend, i, 10 + i * 0.01, 1, dt.AddSeconds(i).ToString("yyyyMMddHHmmms")));
					LastPlayback(instrumentSend, 10 + i * 0.01, 1, dt.AddSeconds(i).ToString("yyyyMMddHHmmss"));
				}

				return;
			}

			Button button = sender as Button;

			switch (sendingData)
			{
				case true:
					timerSend.Enabled	= false;
					button.Content		= string.Format("Send {0}", instrumentSend);
					sendingData			= false;
					break;

				case false:
					priceSend			= 1.00;
					timerSend.Enabled	= true;
					button.Content		= string.Format("Stop Sending {0}", instrumentSend);
					sendingData			= true;
					break;
			}
		}
		
		private void LastTimerElapsed(object sender, System.Timers.ElapsedEventArgs args)
		{
			if (priceSend < 1.04)
				priceSend += .01;
			else
				priceSend = 1.00;

			int success = Last(instrumentSend, priceSend, size);

			Console.WriteLine(string.Format("{0} | last success: {1}", DateTime.Now, success));
		}

		private void MarketDataTimerElapsed(object sender, System.Timers.ElapsedEventArgs args)
		{
			askPriceReceive		= MarketData(instrumentReceive, 2);
			bidPriceReceive		= MarketData(instrumentReceive, 1);
			lastPriceReceive	= MarketData(instrumentReceive, 0);

			this.Dispatcher.InvokeAsync(new Action(() =>
			{
				AskTextBlock.Text	= askPriceReceive.ToString("N2");
				BidTextBlock.Text	= bidPriceReceive.ToString("N2");
				LastTextBlock.Text	= lastPriceReceive.ToString("N2");
			}));

			Console.WriteLine(string.Format( "{0} | {1} | Last: {2}, Ask: {3}, Bid: {4}", DateTime.Now, instrumentReceive, lastPriceReceive, askPriceReceive, bidPriceReceive ));
		}

		private void SetSendType(object sender, RoutedEventArgs e)
		{
			RadioButton button = sender as RadioButton;

			if (button.Content.ToString() == "Live")
				sendLive = true;

			else if (button.Content.ToString() == "Historical")
				sendLive = false;
		}
	}
}
